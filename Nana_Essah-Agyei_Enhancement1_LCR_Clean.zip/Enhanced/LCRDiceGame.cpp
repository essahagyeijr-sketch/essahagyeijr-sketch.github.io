/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS 499 Computer Science Capstone
* Assignment: Milestone Two - Enhanced LCR Dice Game
*
* Description:
* Enhanced version of the Left Center Right (LCR) dice game.
*
* Improvements include:
* - Stronger user input validation
* - Rules file error handling
* - Smaller reusable functions
* - Reduced repeated logic
* - Improved code organization
* - Improved maintainability
******************************************************************************/

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

#include "Dice.h"
#include "player.h"

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::numeric_limits;
using std::streamsize;
using std::string;
using std::vector;

namespace
{
    // LCR requires at least three players.
    constexpr int MIN_PLAYERS = 3;

    // A player can roll no more than three dice per turn.
    constexpr int MAX_DICE_PER_TURN = 3;


    // Displays the game rules from the rules.txt file.
    // If the file cannot be opened, the game continues safely.
    void displayRules(const string& fileName)
    {
        ifstream file(fileName);

        if (!file.is_open())
        {
            cout << "Warning: Unable to open "
                << fileName
                << ". The game will continue without "
                << "displaying the rules."
                << endl;

            return;
        }

        string line;

        while (std::getline(file, line))
        {
            cout << line << endl;
        }

        cout << endl;
    }


    // Prompts the user until a valid number of players is entered.
    int getValidNumberOfPlayers()
    {
        int numPlayers = 0;

        while (true)
        {
            cout << "Enter number of players ("
                << MIN_PLAYERS
                << " or more): ";

            if (cin >> numPlayers &&
                numPlayers >= MIN_PLAYERS)
            {
                cin.ignore(
                    numeric_limits<streamsize>::max(),
                    '\n');

                return numPlayers;
            }

            cout << "Invalid input. Please enter a whole "
                << "number of at least "
                << MIN_PLAYERS
                << "."
                << endl;

            // Clear the error state caused by invalid input.
            cin.clear();

            // Remove invalid input from the input stream.
            cin.ignore(
                numeric_limits<streamsize>::max(),
                '\n');
        }
    }


    // Checks whether a string contains only spaces.
    bool isBlank(const string& value)
    {
        return std::all_of(
            value.begin(),
            value.end(),
            [](unsigned char ch)
            {
                return std::isspace(ch) != 0;
            });
    }


    // Prompts the user until a valid player name is entered.
    string getValidPlayerName(int playerNumber)
    {
        string name;

        while (true)
        {
            cout << "Enter Player "
                << playerNumber
                << " name: ";

            std::getline(cin, name);

            if (!name.empty() && !isBlank(name))
            {
                return name;
            }

            cout << "Player name cannot be empty. "
                << "Please try again."
                << endl;
        }
    }


    // Creates all players and stores them in a vector.
    vector<Player> createPlayers(int numPlayers)
    {
        vector<Player> players;

        // Reserve memory for the expected number of players.
        players.reserve(numPlayers);

        for (int i = 0; i < numPlayers; ++i)
        {
            string playerName =
                getValidPlayerName(i + 1);

            players.emplace_back(playerName);
        }

        return players;
    }


    // Counts the number of players who still have chips.
    int countActivePlayers(
        const vector<Player>& players)
    {
        int activePlayers = 0;

        for (const Player& player : players)
        {
            if (player.getChips() > 0)
            {
                ++activePlayers;
            }
        }

        return activePlayers;
    }


    // Determines how many dice the current player can roll.
    int getRollCount(const Player& player)
    {
        return std::min(
            player.getChips(),
            MAX_DICE_PER_TURN);
    }


    // Processes one dice result and moves a chip when needed.
    void processRoll(
        char result,
        int currentIndex,
        vector<Player>& players,
        int& center)
    {
        const int numPlayers =
            static_cast<int>(players.size());

        switch (result)
        {
        case 'L':
        {
            if (players[currentIndex].removeChip())
            {
                const int leftIndex =
                    (currentIndex - 1 + numPlayers)
                    % numPlayers;

                players[leftIndex].addChip();
            }

            break;
        }

        case 'R':
        {
            if (players[currentIndex].removeChip())
            {
                const int rightIndex =
                    (currentIndex + 1)
                    % numPlayers;

                players[rightIndex].addChip();
            }

            break;
        }

        case 'C':
        {
            if (players[currentIndex].removeChip())
            {
                ++center;
            }

            break;
        }

        default:
            // A dot means the player keeps the chip.
            break;
        }
    }


    // Handles one complete turn for a player.
    void playTurn(
        int playerIndex,
        vector<Player>& players,
        const Dice& dice,
        int& center)
    {
        // Skip a player who currently has no chips.
        if (players[playerIndex].getChips() <= 0)
        {
            return;
        }

        cout << endl
            << players[playerIndex].getName()
            << "'s turn"
            << endl;

        const int rolls =
            getRollCount(players[playerIndex]);

        for (int rollNumber = 0;
            rollNumber < rolls;
            ++rollNumber)
        {
            const char result = dice.roll();

            cout << result << " ";

            processRoll(
                result,
                playerIndex,
                players,
                center);
        }

        cout << endl;
    }


    // Finds and displays the winning player.
    void displayWinner(
        const vector<Player>& players,
        int center)
    {
        cout << endl;

        for (const Player& player : players)
        {
            if (player.getChips() > 0)
            {
                cout << "Winner is "
                    << player.getName()
                    << "!"
                    << endl;

                cout << "Chips in center: "
                    << center
                    << endl;

                return;
            }
        }

        cout << "No winner could be determined."
            << endl;
    }
}


int main()
{
    // Seed the random number generator.
    std::srand(
        static_cast<unsigned int>(
            std::time(nullptr)));

    // Display the rules if rules.txt is available.
    displayRules("rules.txt");

    // Get a validated number of players.
    const int numPlayers =
        getValidNumberOfPlayers();

    // Create the players using validated names.
    vector<Player> players =
        createPlayers(numPlayers);

    Dice dice;

    int center = 0;


    // Continue until only one player has chips.
    while (countActivePlayers(players) > 1)
    {
        for (int i = 0;
            i < numPlayers;
            ++i)
        {
            playTurn(
                i,
                players,
                dice,
                center);

            // Stop the round immediately when a winner exists.
            if (countActivePlayers(players) == 1)
            {
                break;
            }
        }
    }


    // Display the final winner.
    displayWinner(
        players,
        center);

    return 0;
}