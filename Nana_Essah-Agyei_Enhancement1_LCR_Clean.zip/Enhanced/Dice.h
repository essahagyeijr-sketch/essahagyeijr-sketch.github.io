/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS 499 Computer Science Capstone
* Assignment: Milestone Two - Enhanced LCR Dice Game
*
* Description:
* Declares the Dice class used to simulate an LCR die.
******************************************************************************/

#ifndef DICE_H
#define DICE_H

class Dice
{
public:
    // Returns one of the valid LCR outcomes: L, R, C, or .
    char roll() const;
};

#endif