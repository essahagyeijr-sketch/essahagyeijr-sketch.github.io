/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS 499 Computer Science Capstone
* Assignment: Milestone Two - Enhanced LCR Dice Game
*
* Description:
* Declares the Player class, which stores a player's name and chip count.
******************************************************************************/

#ifndef PLAYER_H
#define PLAYER_H

#include <string>

class Player
{
private:
    std::string name;
    int chips;

public:
    // Creates a player with an empty name and three starting chips.
    Player();

    // Creates a named player with three starting chips.
    explicit Player(const std::string& playerName);

    // Returns the player's name.
    const std::string& getName() const;

    // Returns the player's current chip count.
    int getChips() const;

    // Adds one chip to the player.
    void addChip();

    // Removes one chip if possible.
    // Returns true if a chip was successfully removed.
    bool removeChip();
};

#endif