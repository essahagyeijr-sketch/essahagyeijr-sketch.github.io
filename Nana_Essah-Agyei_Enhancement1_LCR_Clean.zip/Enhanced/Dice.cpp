/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS 499 Computer Science Capstone
* Assignment: Milestone Two - Enhanced LCR Dice Game
*
* Description:
* Implements the Dice class. Each roll simulates one six-sided LCR die:
* one L, one R, one C, and three dot faces.
******************************************************************************/

#include "Dice.h"
#include <cstdlib>

char Dice::roll() const
{
    const int number = std::rand() % 6;

    switch (number)
    {
    case 0:
        return 'L';

    case 1:
        return 'R';

    case 2:
        return 'C';

    default:
        return '.';
    }
}