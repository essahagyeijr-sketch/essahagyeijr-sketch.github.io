/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS 499 Computer Science Capstone
* Assignment: Milestone Two - Enhanced LCR Dice Game
*
* Description:
* Implements the Player class used by the LCR Dice Game.
******************************************************************************/

#include "player.h"

Player::Player() : name(""), chips(3)
{
}

Player::Player(const std::string& playerName)
    : name(playerName), chips(3)
{
}

const std::string& Player::getName() const
{
    return name;
}

int Player::getChips() const
{
    return chips;
}

void Player::addChip()
{
    ++chips;
}

bool Player::removeChip()
{
    if (chips <= 0)
    {
        return false;
    }

    --chips;
    return true;
}