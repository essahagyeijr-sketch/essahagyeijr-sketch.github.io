# Travlr Getaways Database Enhancement

This project transforms the original static Travlr website template into a database-backed application for CS 499 Milestone Four.

## Enhancements
- Normalized SQLite `trips` table with constraints and indexes
- REST API for create, read, update, and delete operations
- Server-side validation and duplicate-code protection
- Centralized database connection and safe parameterized queries
- Consistent HTTP status codes and sanitized error responses
- Dynamic travel page populated from the database
- Administrative CRUD page at `/admin.html`
- Helmet security headers and JSON request-size limits

## Run
1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm run seed`.
5. Run `npm start`.
6. Open `http://localhost:3000/travel.html` and `http://localhost:3000/admin.html`.

The generated `database/travlr.db` file is intentionally excluded from the submitted source. Run the seed command to create it.
