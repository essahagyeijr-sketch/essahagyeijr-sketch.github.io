/** Seeds the Travlr database with three sample travel packages. */
const fs = require('fs');
const path = require('path');
const db = require('../src/database');

const trips = [
  ['GALE-7', 'Gale Reef Adventure', 'Gale Reef', '2026-09-12', 7, 1299.00, 'images/reef1.jpg', 'A seven-day reef getaway with guided diving and beachfront lodging.', 1],
  ['DAWSON-5', "Dawson's Reef Escape", "Dawson's Reef", '2026-10-03', 5, 999.00, 'images/reef2.jpg', 'A five-day tropical escape featuring snorkeling, kayaking, and resort meals.', 1],
  ['CLAIRE-6', "Claire's Reef Discovery", "Claire's Reef", '2026-11-14', 6, 1149.00, 'images/reef3.jpg', 'A six-day discovery package with reef tours and comfortable resort accommodations.', 1]
];

(async () => {
  try {
    const schema = fs.readFileSync(path.join(__dirname, '..', 'database', 'schema.sql'), 'utf8');
    for (const statement of schema.split(';').map(s => s.trim()).filter(Boolean)) await db.run(statement);
    await db.run('DELETE FROM trips');
    for (const trip of trips) {
      await db.run(`INSERT INTO trips (code,name,destination,start_date,duration_days,price_per_person,image,description,active)
                    VALUES (?,?,?,?,?,?,?,?,?)`, trip);
    }
    console.log('Database seeded with sample trips.');
  } catch (error) {
    console.error('Seed failed:', error);
    process.exitCode = 1;
  } finally { await db.close(); }
})();
