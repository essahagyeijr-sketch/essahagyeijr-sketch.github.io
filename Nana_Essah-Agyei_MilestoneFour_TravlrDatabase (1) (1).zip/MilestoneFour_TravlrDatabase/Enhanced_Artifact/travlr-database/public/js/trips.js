async function loadTrips() {
  const container = document.getElementById('sites');
  try {
    const response = await fetch('/api/trips');
    if (!response.ok) throw new Error('Could not retrieve trip data.');
    const trips = await response.json();
    container.innerHTML = trips.map(trip => `
      <li>
        <img src="${escapeHtml(trip.image)}" alt="${escapeHtml(trip.name)}" />
        <h2>${escapeHtml(trip.name)}</h2>
        <p><strong>${escapeHtml(trip.destination)}</strong> | ${trip.duration_days} days | $${Number(trip.price_per_person).toFixed(2)} per person</p>
        <p>Starts ${escapeHtml(trip.start_date)}. ${escapeHtml(trip.description)}</p>
      </li>`).join('') || '<li><p>No active trips are currently available.</p></li>';
  } catch (error) {
    container.innerHTML = '<li><p>Trip information is temporarily unavailable.</p></li>';
  }
}
function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
document.addEventListener('DOMContentLoaded', loadTrips);
