-- CS 499 Milestone Four - Travlr database schema
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS trips (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE CHECK(length(trim(code)) BETWEEN 2 AND 12),
    name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 2 AND 100),
    destination TEXT NOT NULL CHECK(length(trim(destination)) BETWEEN 2 AND 100),
    start_date TEXT NOT NULL,
    duration_days INTEGER NOT NULL CHECK(duration_days BETWEEN 1 AND 365),
    price_per_person REAL NOT NULL CHECK(price_per_person >= 0),
    image TEXT NOT NULL DEFAULT 'images/reef1.jpg',
    description TEXT NOT NULL CHECK(length(trim(description)) BETWEEN 10 AND 1000),
    active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0, 1)),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_trips_start_date ON trips(start_date);
CREATE INDEX IF NOT EXISTS idx_trips_destination ON trips(destination);
CREATE INDEX IF NOT EXISTS idx_trips_active ON trips(active);
