/** Validates and normalizes trip data before it reaches the database. */
function validateTrip(input, partial = false) {
  const errors = [];
  const output = {};
  const required = ['code', 'name', 'destination', 'start_date', 'duration_days', 'price_per_person', 'description'];

  for (const field of required) {
    if (!partial && (input[field] === undefined || String(input[field]).trim() === '')) {
      errors.push(`${field} is required.`);
    }
  }

  if (input.code !== undefined) {
    output.code = String(input.code).trim().toUpperCase();
    if (!/^[A-Z0-9-]{2,12}$/.test(output.code)) errors.push('code must be 2-12 letters, numbers, or hyphens.');
  }
  for (const field of ['name', 'destination', 'description', 'image']) {
    if (input[field] !== undefined) output[field] = String(input[field]).trim();
  }
  if (output.name !== undefined && (output.name.length < 2 || output.name.length > 100)) errors.push('name must be 2-100 characters.');
  if (output.destination !== undefined && (output.destination.length < 2 || output.destination.length > 100)) errors.push('destination must be 2-100 characters.');
  if (output.description !== undefined && (output.description.length < 10 || output.description.length > 1000)) errors.push('description must be 10-1000 characters.');

  if (input.start_date !== undefined) {
    output.start_date = String(input.start_date).trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(output.start_date) || Number.isNaN(Date.parse(`${output.start_date}T00:00:00Z`))) {
      errors.push('start_date must be a valid YYYY-MM-DD date.');
    }
  }
  if (input.duration_days !== undefined) {
    output.duration_days = Number(input.duration_days);
    if (!Number.isInteger(output.duration_days) || output.duration_days < 1 || output.duration_days > 365) errors.push('duration_days must be an integer from 1-365.');
  }
  if (input.price_per_person !== undefined) {
    output.price_per_person = Number(input.price_per_person);
    if (!Number.isFinite(output.price_per_person) || output.price_per_person < 0) errors.push('price_per_person must be zero or greater.');
  }
  if (input.active !== undefined) output.active = input.active === true || input.active === 1 || input.active === '1' ? 1 : 0;
  if (!output.image && !partial) output.image = 'images/reef1.jpg';

  return { errors, value: output };
}
module.exports = { validateTrip };
