/**
 * Nana Essah-Agyei, Jr. | CS 499 | Milestone Four
 * Centralized SQLite connection and promise-based query helpers.
 */
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const databasePath = path.join(__dirname, '..', 'database', 'travlr.db');
const db = new sqlite3.Database(databasePath, (error) => {
  if (error) {
    console.error('Unable to connect to the Travlr database:', error.message);
    process.exit(1);
  }
  console.log(`Connected to SQLite database: ${databasePath}`);
});

db.run('PRAGMA foreign_keys = ON');

const action = {
  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      db.run(sql, params, function (error) {
        if (error) return reject(error);
        resolve({ id: this.lastID, changes: this.changes });
      });
    });
  },
  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      db.get(sql, params, (error, row) => error ? reject(error) : resolve(row));
    });
  },
  all(sql, params = []) {
    return new Promise((resolve, reject) => {
      db.all(sql, params, (error, rows) => error ? reject(error) : resolve(rows));
    });
  },
  close() {
    return new Promise((resolve, reject) => {
      db.close((error) => error ? reject(error) : resolve());
    });
  }
};

module.exports = action;
