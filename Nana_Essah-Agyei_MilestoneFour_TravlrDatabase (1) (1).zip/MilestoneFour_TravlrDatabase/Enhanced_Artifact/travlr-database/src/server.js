/**
 * Nana Essah-Agyei, Jr. | CS 499 | Milestone Four - Database Enhancement
 * Express API and static-site host for the database-backed Travlr application.
 */
const express = require('express');
const helmet = require('helmet');
const path = require('path');
const fs = require('fs');
const db = require('./database');
const { validateTrip } = require('./validation');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

async function initializeDatabase() {
  const schema = fs.readFileSync(path.join(__dirname, '..', 'database', 'schema.sql'), 'utf8');
  for (const statement of schema.split(';').map(s => s.trim()).filter(Boolean)) await db.run(statement);
}

app.get('/api/trips', async (req, res, next) => {
  try {
    const includeInactive = req.query.includeInactive === 'true';
    const sql = `SELECT * FROM trips ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY start_date, name`;
    res.json(await db.all(sql));
  } catch (error) { next(error); }
});

app.get('/api/trips/:id', async (req, res, next) => {
  try {
    const trip = await db.get('SELECT * FROM trips WHERE id = ?', [req.params.id]);
    if (!trip) return res.status(404).json({ message: 'Trip not found.' });
    res.json(trip);
  } catch (error) { next(error); }
});

app.post('/api/trips', async (req, res, next) => {
  const { errors, value } = validateTrip(req.body);
  if (errors.length) return res.status(400).json({ message: 'Validation failed.', errors });
  try {
    const result = await db.run(`INSERT INTO trips
      (code, name, destination, start_date, duration_days, price_per_person, image, description, active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [value.code, value.name, value.destination, value.start_date, value.duration_days,
       value.price_per_person, value.image, value.description, value.active ?? 1]);
    res.status(201).json(await db.get('SELECT * FROM trips WHERE id = ?', [result.id]));
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT') return res.status(409).json({ message: 'Trip data violates a database rule. The trip code may already exist.' });
    next(error);
  }
});

app.put('/api/trips/:id', async (req, res, next) => {
  const { errors, value } = validateTrip(req.body);
  if (errors.length) return res.status(400).json({ message: 'Validation failed.', errors });
  try {
    const result = await db.run(`UPDATE trips SET code=?, name=?, destination=?, start_date=?, duration_days=?,
      price_per_person=?, image=?, description=?, active=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`,
      [value.code, value.name, value.destination, value.start_date, value.duration_days,
       value.price_per_person, value.image, value.description, value.active ?? 1, req.params.id]);
    if (!result.changes) return res.status(404).json({ message: 'Trip not found.' });
    res.json(await db.get('SELECT * FROM trips WHERE id = ?', [req.params.id]));
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT') return res.status(409).json({ message: 'Trip data violates a database rule. The trip code may already exist.' });
    next(error);
  }
});

app.delete('/api/trips/:id', async (req, res, next) => {
  try {
    const result = await db.run('DELETE FROM trips WHERE id = ?', [req.params.id]);
    if (!result.changes) return res.status(404).json({ message: 'Trip not found.' });
    res.status(204).send();
  } catch (error) { next(error); }
});

app.use('/api', (req, res) => res.status(404).json({ message: 'API route not found.' }));
app.use((error, req, res, next) => {
  console.error(error);
  res.status(500).json({ message: 'An unexpected database or server error occurred.' });
});

initializeDatabase().then(() => {
  app.listen(PORT, () => console.log(`Travlr is running at http://localhost:${PORT}`));
}).catch(error => {
  console.error('Database initialization failed:', error);
  process.exit(1);
});

async function shutdown() {
  try { await db.close(); } finally { process.exit(0); }
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
