CS 499 Milestone Four - Database Enhancement

Original_Artifact contains the unchanged Travlr website template.
Enhanced_Artifact contains the database-backed version with SQLite, an Express API, validation, CRUD operations, and an administration page.

See Enhanced_Artifact/travlr-database/README.md for setup and testing instructions.
