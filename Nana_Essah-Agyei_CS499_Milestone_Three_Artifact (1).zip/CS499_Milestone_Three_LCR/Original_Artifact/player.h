/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS-210 Programming Languages
* Date: June 21, 2026
* Assignment: Final Project - Player Class Header
*
* Description:
* This header file declares the Player class used by the LCR Dice Game.
* It defines the data members and public methods used to manage player
* information throughout the game.
******************************************************************************/
#ifndef PLAYER_H
#define PLAYER_H

#include <string>
using namespace std;

// Player class stores each player's name and number of chips.
class Player
{
private:
    string name;
    int chips;

public:
    // Default constructor
    Player();

    // Constructor that sets the player's name
    Player(string playerName);

    // Returns the player's name
    string getName();

    // Returns the player's current chip count
    int getChips();

    // Adds one chip to the player
    void addChip();

    // Removes one chip from the player if they have chips
    void removeChip();
};

#endif