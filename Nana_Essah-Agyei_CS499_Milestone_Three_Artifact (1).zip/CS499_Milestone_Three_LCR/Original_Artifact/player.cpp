/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS-210 Programming Languages
* Date: June 21, 2026
* Assignment: Final Project - Player Class
*
* Description:
* This file contains the implementation of the Player class. The Player
* class stores each player's name and chip count and provides functions
* to add chips, remove chips, and retrieve player information.
******************************************************************************/
#include "Player.h"

// Default constructor gives the player no name and 3 chips.
Player::Player()
{
    name = "";
    chips = 3;
}

// Constructor sets the player's name and gives 3 starting chips.
Player::Player(string playerName)
{
    name = playerName;
    chips = 3;
}

// Returns the player's name.
string Player::getName()
{
    return name;
}

// Returns the number of chips the player currently has.
int Player::getChips()
{
    return chips;
}

// Adds one chip to the player.
void Player::addChip()
{
    chips++;
}

// Removes one chip only if the player has at least one chip.
void Player::removeChip()
{
    if (chips > 0)
    {
        chips--;
    }
}