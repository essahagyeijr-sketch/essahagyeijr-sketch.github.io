/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS-210 Programming Languages
* Date: June 21, 2026
* Assignment: Final Project - LCR Dice Game
*
* Description:
* This program simulates the Left Center Right (LCR) dice game using
* object-oriented programming principles. The game reads the rules from
* a text file, allows multiple players to play through the command line,
* and determines the winner when only one player has chips remaining.
******************************************************************************/
#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>

#include "Player.h"
#include "Dice.h"

using namespace std;
int main()
{
    srand(time(0));

    ifstream file("rules.txt");

    string line;

    while (getline(file, line))
    {
        cout << line << endl;
    }

    file.close();

    cout << endl;
    int numPlayers;

    cout << "Enter number of players: ";
    cin >> numPlayers;

    vector<Player> players;
    for (int i = 0; i < numPlayers; i++)
    {
        string name;

        cout << "Enter Player " << i + 1 << " name: ";
        cin >> name;

        players.push_back(Player(name));
    }
    Dice dice;
    int center = 0;
    bool gameOver = false;
    while (!gameOver)
    {
        for (int i = 0; i < numPlayers; i++)
        {
            int chips = players[i].getChips();

            if (chips == 0)
                continue;
            int rolls = chips;

            if (rolls > 3)
                rolls = 3;
            cout << endl;
            cout << players[i].getName() << "'s turn" << endl;
            for (int j = 0; j < rolls; j++)
            {
                char result = dice.roll();

                cout << result << " ";
                if (result == 'L')
                {
                    players[i].removeChip();

                    int left = (i - 1 + numPlayers) % numPlayers;

                    players[left].addChip();
                }

                else if (result == 'R')
                {
                    players[i].removeChip();

                    int right = (i + 1) % numPlayers;

                    players[right].addChip();
                }

                else if (result == 'C')
                {
                    players[i].removeChip();

                    center++;
                }
            }

            cout << endl;
            int active = 0;

            for (Player p : players)
            {
                if (p.getChips() > 0)
                    active++;
            }

            if (active == 1)
            {
                gameOver = true;
                break;
            }
        }
    }
    cout << endl;

    for (Player p : players)
    {
        if (p.getChips() > 0)
        {
            cout << "Winner is "
                << p.getName()
                << "!" << endl;
        }
    }

    return 0;
}