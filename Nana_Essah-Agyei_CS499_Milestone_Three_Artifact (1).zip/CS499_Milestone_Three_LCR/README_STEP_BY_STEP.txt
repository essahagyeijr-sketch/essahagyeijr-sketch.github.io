CS 499 MILESTONE THREE - STEP-BY-STEP

1. Open the Enhanced_Artifact folder.
2. Double-click the Visual Studio project file LCRDiceGame.vcxproj.
3. In Solution Explorer, open LCRDiceGame.cpp, player.cpp, player.h, Dice.cpp, and Dice.h.
4. Select Build > Build Solution.
5. Start the program using the green Local Windows Debugger button.
6. Test an invalid player count, such as 2, and confirm the program asks again.
7. Enter at least three player names and allow the game to run.
8. Confirm that chip counts display after each turn and that a winner is announced.
9. Take screenshots of the running program for your records.
10. Submit this ZIP file together with the separate Word narrative.

The Original_Artifact folder contains the unchanged original project.
The Enhanced_Artifact folder contains the algorithms and data structures enhancement.
