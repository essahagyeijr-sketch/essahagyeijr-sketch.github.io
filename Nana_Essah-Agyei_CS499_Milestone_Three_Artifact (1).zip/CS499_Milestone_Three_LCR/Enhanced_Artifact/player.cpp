/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS 499 Computer Science Capstone
* Date: July 2026
* Assignment: Milestone Three - Algorithms and Data Structures
* Artifact: Enhanced LCR Dice Game - Player Class
*
* Description:
* This file implements the Player class. Each Player object stores a name and
* chip count. Const-correct getters allow player data to be read safely when
* the vector is passed to algorithms by constant reference.
******************************************************************************/
#include "player.h"

Player::Player() : name(""), chips(3)
{
}

Player::Player(const std::string& playerName) : name(playerName), chips(3)
{
}

const std::string& Player::getName() const
{
    return name;
}

int Player::getChips() const
{
    return chips;
}

void Player::addChip()
{
    ++chips;
}

void Player::removeChip()
{
    if (chips > 0)
    {
        --chips;
    }
}
