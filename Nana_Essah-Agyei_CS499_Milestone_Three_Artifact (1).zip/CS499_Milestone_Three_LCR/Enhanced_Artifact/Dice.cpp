/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS-210 Programming Languages
* Date: June 21, 2026
* Assignment: Final Project - Dice Class
*
* Description:
* This file contains the implementation of the Dice class. The Dice
* class simulates rolling an LCR die and returns one of the four
* possible outcomes: L, R, C, or dot (.).
******************************************************************************/
#include "Dice.h"
#include <cstdlib>

// Rolls one LCR die.
// 1 side = L, 1 side = R, 1 side = C, and 3 sides = dot.
char Dice::roll()
{
    int number = rand() % 6;

    switch (number)
    {
    case 0:
        return 'L';

    case 1:
        return 'R';

    case 2:
        return 'C';

    default:
        return '.';
    }
}