/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS-210 Programming Languages
* Date: June 21, 2026
* Assignment: Final Project - Dice Class Header
*
* Description:
* This header file declares the Dice class used by the LCR Dice Game.
* It contains the function prototype for rolling an LCR die.
******************************************************************************/
#ifndef DICE_H
#define DICE_H

// Dice class handles rolling one LCR die.
class Dice
{
public:
    // Rolls the die and returns L, R, C, or .
    char roll();
};

#endif