/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS 499 Computer Science Capstone
* Date: July 2026
* Assignment: Milestone Three - Algorithms and Data Structures
* Artifact: Enhanced LCR Dice Game - Player Class Header
*
* Description:
* This header declares the Player class used by the enhanced LCR Dice Game.
* Const-correct accessor functions and efficient parameter passing improve
* maintainability and support safe traversal of the player vector.
******************************************************************************/
#ifndef PLAYER_H
#define PLAYER_H

#include <string>

class Player
{
private:
    std::string name;
    int chips;

public:
    Player();
    explicit Player(const std::string& playerName);

    const std::string& getName() const;
    int getChips() const;

    void addChip();
    void removeChip();
};

#endif
