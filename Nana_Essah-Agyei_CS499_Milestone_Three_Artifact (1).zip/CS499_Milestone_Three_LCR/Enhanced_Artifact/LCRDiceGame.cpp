/******************************************************************************
* Name: Nana Essah-Agyei
* Course: CS 499 Computer Science Capstone
* Date: July 2026
* Assignment: Milestone Three - Algorithms and Data Structures
* Artifact: Enhanced LCR Dice Game
*
* Description:
* This enhanced version of the LCR Dice Game demonstrates the use of a vector
* to store dynamic player data and reusable algorithms to count active players,
* determine a winner, calculate dice rolls, transfer chips, validate input, and
* display game status. The improvements make the program safer, clearer, and
* easier to maintain while preserving the original game rules.
******************************************************************************/
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

#include "Dice.h"
#include "player.h"

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::numeric_limits;
using std::streamsize;
using std::string;
using std::vector;

namespace
{
    constexpr int MIN_PLAYERS = 3;
    constexpr int MAX_DICE_PER_TURN = 3;

    void displayRules(const string& fileName)
    {
        ifstream file(fileName);

        if (!file.is_open())
        {
            cout << "Rules file could not be opened. The game will continue." << endl;
            return;
        }

        string line;
        while (getline(file, line))
        {
            cout << line << endl;
        }
    }

    int getValidatedPlayerCount()
    {
        int playerCount = 0;

        while (true)
        {
            cout << "Enter number of players (minimum " << MIN_PLAYERS << "): ";

            if (cin >> playerCount && playerCount >= MIN_PLAYERS)
            {
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                return playerCount;
            }

            cout << "Invalid entry. Please enter a whole number of at least "
                 << MIN_PLAYERS << "." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }

    string getValidatedPlayerName(int playerNumber)
    {
        string name;

        while (name.empty())
        {
            cout << "Enter Player " << playerNumber << " name: ";
            getline(cin, name);

            // Reject names that contain only spaces.
            const bool onlyWhitespace = std::all_of(
                name.begin(), name.end(),
                [](unsigned char character)
                {
                    return std::isspace(character) != 0;
                });

            if (onlyWhitespace)
            {
                name.clear();
            }

            if (name.empty())
            {
                cout << "Player name cannot be blank." << endl;
            }
        }

        return name;
    }

    int countActivePlayers(const vector<Player>& players)
    {
        return static_cast<int>(std::count_if(
            players.begin(), players.end(),
            [](const Player& player)
            {
                return player.getChips() > 0;
            }));
    }

    int determineWinnerIndex(const vector<Player>& players)
    {
        for (std::size_t index = 0; index < players.size(); ++index)
        {
            if (players[index].getChips() > 0)
            {
                return static_cast<int>(index);
            }
        }

        return -1;
    }

    int calculateRollCount(const Player& player)
    {
        return std::min(player.getChips(), MAX_DICE_PER_TURN);
    }

    void displayPlayerStatus(const vector<Player>& players, int centerChips)
    {
        cout << "\nCurrent chip counts:" << endl;
        for (const Player& player : players)
        {
            cout << "  " << player.getName() << ": "
                 << player.getChips() << endl;
        }
        cout << "  Center: " << centerChips << endl;
    }

    void processRoll(vector<Player>& players,
                     std::size_t currentIndex,
                     char result,
                     int& centerChips)
    {
        const std::size_t playerCount = players.size();
        const std::size_t leftIndex =
            (currentIndex + playerCount - 1) % playerCount;
        const std::size_t rightIndex =
            (currentIndex + 1) % playerCount;

        switch (result)
        {
        case 'L':
            players[currentIndex].removeChip();
            players[leftIndex].addChip();
            break;

        case 'R':
            players[currentIndex].removeChip();
            players[rightIndex].addChip();
            break;

        case 'C':
            players[currentIndex].removeChip();
            ++centerChips;
            break;

        default:
            // A dot means the player keeps the chip.
            break;
        }
    }
}

int main()
{
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    displayRules("rules.txt");
    cout << endl;

    const int numberOfPlayers = getValidatedPlayerCount();

    vector<Player> players;
    players.reserve(numberOfPlayers);

    for (int index = 0; index < numberOfPlayers; ++index)
    {
        const string name = getValidatedPlayerName(index + 1);
        players.emplace_back(name);
    }

    Dice dice;
    int centerChips = 0;
    int roundNumber = 1;

    displayPlayerStatus(players, centerChips);

    while (countActivePlayers(players) > 1)
    {
        cout << "\n========== Round " << roundNumber << " ==========" << endl;

        for (std::size_t index = 0; index < players.size(); ++index)
        {
            if (players[index].getChips() == 0)
            {
                continue;
            }

            const int rollCount = calculateRollCount(players[index]);
            cout << "\n" << players[index].getName() << "'s turn: ";

            for (int rollNumber = 0; rollNumber < rollCount; ++rollNumber)
            {
                const char result = dice.roll();
                cout << result << ' ';
                processRoll(players, index, result, centerChips);
            }

            cout << endl;
            displayPlayerStatus(players, centerChips);

            if (countActivePlayers(players) == 1)
            {
                break;
            }
        }

        ++roundNumber;
    }

    const int winnerIndex = determineWinnerIndex(players);

    if (winnerIndex >= 0)
    {
        cout << "\nWinner is "
             << players[static_cast<std::size_t>(winnerIndex)].getName()
             << " with "
             << players[static_cast<std::size_t>(winnerIndex)].getChips()
             << " chip(s)!" << endl;
    }
    else
    {
        cout << "\nNo winner could be determined." << endl;
    }

    return 0;
}
